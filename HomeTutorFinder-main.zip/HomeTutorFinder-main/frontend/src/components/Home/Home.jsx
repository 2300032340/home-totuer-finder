import Expert from "./Expert";
import HomePage from "./HomePage";
import Plans from "./Plans";

function Home(){
    return(
        <>
            <HomePage/>
            <Expert/>
            <Plans/>
        </>
    )
}
export default Home;
